package pack03;

import java.util.Scanner;

public class Score_Process5 {
	static Scanner scan = new Scanner(System.in);
	void main_print() { //상위메뉴 출력
		System.out.println("[학생성적 관리 프로그램]");
		System.out.println("1.학생성적 입력");
		System.out.println("2.학생성적 출력");
		System.out.println("3.학생성적 수정");
		System.out.println("4.학생 개인성적 출력");
		System.out.println("5.등수 처리");
		System.out.println("0.프로그램 종료");
	}//상위메뉴 출력
	
	void stu_input(Student5[]s) { // 1.학생성적 입력
		String name = "";
		int kor=0,eng=0,math=0;
		
		for(int i=Student5.count;i<s.length;i++) {
			System.out.println("이름을 입력하세요 0.상위메뉴이동");
			 String check = scan.next();
			 if(check.equals("0")) {
				 System.out.println("상위메뉴로 이동합니다.");
				 break;
			 }
			 name = check;
			 System.out.println("국어점수를 입력하세요");
			 kor = scan.nextInt();
			 System.out.println("영어점수를 입력하세요");
			 eng = scan.nextInt();
			 System.out.println("수학점수를 입력하세요");
			 math = scan.nextInt();
			 
			 s[i] = new Student5(name,kor,eng,math);
		}
	}// 학생성적 입력
	void top_title() {
		System.out.println("번호\t이름\t국어\t영어\t수학\t합계\t평균\t등수");
		System.out.println("========================================");
	}
	void stu_output(Student5[]s) { // 2.학생성적 출력
		
		for(int i=0; i<Student5.count;i++) {
			System.out.print(s[i].stu_number+"\t");
			System.out.print(s[i].name+"\t");
			System.out.print(s[i].kor+"\t");
			System.out.print(s[i].eng+"\t");
			System.out.print(s[i].math+"\t");
			System.out.print(s[i].total+"\t");
			System.out.printf("%.2f \t",s[i].avg);
			System.out.println(s[i].rank);
		}
	}//학생성적 출력
	
	void stu_update(Student5[]s) { // 3.학생성적 수정
	
		System.out.println("수정할 학생이름 입력");
		String search_name = scan.next();
		System.out.println("[수정할 학생 선택]");
		for(int i=0; i<Student5.count;i++) {
			if(s[i].name.contains(search_name)) {
				System.out.println(i+"."+s[i].name);
			}
		}
		System.out.println("수정할 학생번호 입력");
		int temp_num = scan.nextInt();
		System.out.println("수정할 과목 입력");
		System.out.println("0.국어 1.영어 2.수학");
		int temp_num2 = scan.nextInt();
		
		switch(temp_num2) {
		case 0:
			System.out.println("현재점수 :"+s[temp_num].kor);
			System.out.println("수정할 점수를 입력하세요");
			s[temp_num].kor = scan.nextInt();
			System.out.println("수정된 점수 :"+s[temp_num].kor);
			System.out.println("수정완료");
			break;
		case 1:
			System.out.println("현재점수 :"+s[temp_num].eng);
			System.out.println("수정할 점수를 입력하세요");
			s[temp_num].eng = scan.nextInt();
			System.out.println("수정된 점수 :"+s[temp_num].eng);
			System.out.println("수정완료");
			break;
		case 2:
			System.out.println("현재점수 :"+s[temp_num].math);
			System.out.println("수정할 점수를 입력하세요");
			s[temp_num].math = scan.nextInt();
			System.out.println("수정된 점수 :"+s[temp_num].math);
			System.out.println("수정완료");
			break;
		}
		s[temp_num].total = s[temp_num].kor+s[temp_num].eng+s[temp_num].math;
		s[temp_num].avg = s[temp_num].total/3.0;
		
		
		
	}//학생성적 수정
	
	void stu_oneoutput(Student5[]s) {// 4.학생 개인성적 출력
		
		System.out.println("검색할 학생이름 입력");
		String search_name = scan.next();
		top_title();
		int search_num=-1;
		for(int i=0; i<Student5.count;i++) {
			if(s[i].name.contains(search_name)) {
				System.out.print(s[i].stu_number+"\t");
				System.out.print(s[i].name+"\t");
				System.out.print(s[i].kor+"\t");
				System.out.print(s[i].eng+"\t");
				System.out.print(s[i].math+"\t");
				System.out.print(s[i].total+"\t");
				System.out.printf("%.2f \t",s[i].avg);
				System.out.println(s[i].rank);
			}
		}
		if(search_num==-1) {
			System.out.println("찾는 데이터가 없음");
			return;
		}
	
	
	}// 4.학생 개인성적 출력
	
	
	
	
	//5.등수확인
	void ranking(Student5[]s) {
		for(int i=0; i<Student5.count; i++) {
			int rankNum = 1;
			for(int j=0; j<Student5.count;j++) {
				if(s[i].total<s[j].total) {
					rankNum++;
				}
			}
			s[i].rank = rankNum;
		}
		System.out.println("등수처리 완료");
	}//5.등수확인
	
}//class
