package pack03;

public class Styler extends Product{
	Styler(){
		super("스타일러",130,13);
	}
}
