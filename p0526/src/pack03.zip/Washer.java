package pack03;

public class Washer extends Product {

	Washer(){
		super("트럼",180,18);
	}
}
