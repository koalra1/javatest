package pack03;

public class Refrigerator extends Product{

	Refrigerator(){
		super("비스포크",300,30);
	}
}
