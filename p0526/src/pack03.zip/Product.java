package pack03;

public class Product {
	String pro_name;
	int price;
	int bonusPoint;
	
	Product(){}
	Product(String pro_name,int price,int bonusPoint){
		this.pro_name = pro_name;
		this.price = price;
		this.bonusPoint = bonusPoint;
	}
	
}
