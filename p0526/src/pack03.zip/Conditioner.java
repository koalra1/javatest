package pack03;

public class Conditioner extends Product{
	Conditioner(){
		super("무풍",230,23);
	}
}
